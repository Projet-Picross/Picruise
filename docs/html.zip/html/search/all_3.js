var searchData=
[
  ['init_5fmat_5fcub_16',['init_mat_cub',['../solveur_8c.html#a3f96d4b22a03ea2c69ab27a5c10d82f1',1,'solveur.c']]],
  ['init_5fmatrice_17',['init_matrice',['../generation_8c.html#a3982c02d61d10308139c2879a0dcd517',1,'generation.c']]]
];
