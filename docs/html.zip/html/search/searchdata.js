var indexSectionsWithContent =
{
  0: "acgijmnoprsv",
  1: "acgjmopsv",
  2: "acgijmnoprsv"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Fichiers",
  2: "Fonctions"
};

