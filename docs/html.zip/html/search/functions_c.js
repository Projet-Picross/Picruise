var searchData=
[
  ['solve_188',['solve',['../grille__exacte_8c.html#a2dfb216c910df7260bae9a621875f65f',1,'solve(int grille[N][N], int mat_cond_l[N][N], int mat_cond_c[N][N], int combinaisons[N][300][10]):&#160;grille_exacte.c'],['../picruise__v2_8c.html#a64866b5b6811b41dbcfac3f235fb1fd3',1,'solve(int *grille, int *mat_cond_l, int *mat_cond_c, int *combinaisons, int format):&#160;picruise_v2.c']]],
  ['solveur_189',['solveur',['../picruise__v2_8c.html#ada92a6620a64b7ff7594eace9baa1410',1,'solveur(int *grille, int *jeu, int *mat_cond_l, int *mat_cond_c, int format):&#160;picruise_v2.c'],['../solveur_8c.html#a9cfb6457513c508f07ab896300479a8a',1,'solveur(int grille[N][N], int mat_cond_l[N][N], int mat_cond_c[N][N]):&#160;solveur.c']]],
  ['somme_5fcond_5fl_190',['somme_cond_l',['../grille__exacte_8c.html#a60a0052d2a31d07097f3142bb6fb2534',1,'somme_cond_l(int mat_cond[N][N], int somme_cond[N]):&#160;grille_exacte.c'],['../picruise__v2_8c.html#a4567a89fb4eeb292041acacba9959639',1,'somme_cond_l(int *mat_cond, int *somme_cond, int format):&#160;picruise_v2.c']]],
  ['somme_5fnb_5fcond_191',['somme_nb_cond',['../basique_8c.html#a0cfaf1c4f61a0341915c662a28fddf1d',1,'basique.c']]]
];
