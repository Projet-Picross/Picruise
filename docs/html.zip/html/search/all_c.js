var searchData=
[
  ['pause_61',['pause',['../picruise__v2_8c.html#a2db4123c03ab72cb840c74fe18032568',1,'picruise_v2.c']]],
  ['picruise_2ec_62',['picruise.c',['../picruise_8c.html',1,'']]],
  ['picruise_5fv2_2ec_63',['picruise_v2.c',['../picruise__v2_8c.html',1,'']]],
  ['predefinie_64',['predefinie',['../picruise_8c.html#aa49300b31544e6d6a9af7fbe325e346c',1,'picruise.c']]]
];
