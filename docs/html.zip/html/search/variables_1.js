var searchData=
[
  ['screen_5fwidth_206',['SCREEN_WIDTH',['../picruise_8c.html#a3482785bd2a4c8b307f9e0b6f54e2c36',1,'SCREEN_WIDTH():&#160;picruise.c'],['../picruise__v2_8c.html#a599adbe412c60e0cc5abb86be7ee4507',1,'SCREEN_WIDTH():&#160;picruise_v2.c']]],
  ['screen_5fwidth_207',['screen_width',['../picruise__v2_8c.html#aa4d434a8b93410ea0ed660e48dac41c6',1,'picruise_v2.c']]]
];
