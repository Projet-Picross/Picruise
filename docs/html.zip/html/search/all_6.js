var searchData=
[
  ['nb_5fmax_5fcond_23',['nb_max_cond',['../jeu_8c.html#aa72d59a0f7935c53d168ff81ebe5c820',1,'jeu.c']]],
  ['nombre_5fbloc_24',['nombre_bloc',['../solveur_8c.html#a5ec9e1565622ea0bc2e125dc125fbfb1',1,'solveur.c']]]
];
